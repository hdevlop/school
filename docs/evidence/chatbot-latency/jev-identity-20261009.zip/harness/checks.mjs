import { writeFileSync } from 'node:fs';
const tasks = [
  ['regressions', ['bun', 'test', 'packages/server/tests/chat', 'packages/server/tests/academicYears', 'packages/server/tests/ownership', 'packages/server/tests/security/ChatDiagnostics.test.ts', 'scripts/tests']],
  ['lint', ['bun', 'run', 'lint']],
  ['typecheck', ['bun', 'run', 'typecheck']],
  ['boundaries', ['bun', 'run', 'test:boundaries']],
];
const results = await Promise.all(tasks.map(async ([id, cmd]) => {
  const start = performance.now();
  const child = Bun.spawn(cmd, { stdout: 'pipe', stderr: 'pipe' });
  const [stdout, stderr, exitCode] = await Promise.all([new Response(child.stdout).text(), new Response(child.stderr).text(), child.exited]);
  writeFileSync('.cache/jev-identity-' + id + '.log', stdout + stderr);
  return { id, cmd, exitCode, elapsedMs: performance.now() - start, summary: (stdout + stderr).trim().split(/\r?\n/u).slice(-7) };
}));
writeFileSync('.cache/jev-identity-verification.json', JSON.stringify(results, null, 2));
console.log(JSON.stringify(results));
process.exit(results.some(result => result.exitCode !== 0) ? 1 : 0);
