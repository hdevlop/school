import { readFileSync, writeFileSync } from 'node:fs';
const results = JSON.parse(readFileSync('.cache/jev-identity-verification.json', 'utf8'));
// These script suites share CLI fixture paths, so they must not overlap.
for (const [id, cmd] of [
  ['backend', ['bun', 'test', 'packages/server/tests/chat', 'packages/server/tests/academicYears', 'packages/server/tests/ownership', 'packages/server/tests/security/ChatDiagnostics.test.ts']],
  ['boundaries-final', ['bun', 'run', 'test:boundaries']],
]) {
  const start = performance.now(), child = Bun.spawn(cmd, { stdout: 'pipe', stderr: 'pipe' });
  const [stdout, stderr, exitCode] = await Promise.all([new Response(child.stdout).text(), new Response(child.stderr).text(), child.exited]);
  writeFileSync('.cache/jev-identity-' + id + '.log', stdout + stderr);
  const result = { id, cmd, exitCode, elapsedMs: performance.now() - start, summary: (stdout + stderr).trim().split(/\r?\n/u).slice(-8) };
  results.push(result); console.log(JSON.stringify(result));
  writeFileSync('.cache/jev-identity-verification.json', JSON.stringify(results, null, 2));
  if (exitCode !== 0) process.exit(1);
}
