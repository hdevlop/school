import 'reflect-metadata';
import { readFileSync, writeFileSync } from 'node:fs';
import { parseUiStream } from '../scripts/chatbot-roles.mjs';

const fixture = process.argv.includes('--history');
const url = new URL(process.env.DB_URL!);
if (!['localhost', '127.0.0.1', '[::1]'].includes(url.hostname)) throw Error('Local data only');
if (fixture) url.pathname = '/school_history_test';
process.env.DB_URL = url.toString(); process.env.REDIS_URL = ''; process.env.NODE_ENV = 'development';
process.env.CHATBOT_JEV_MODE = 'off'; process.env.CHATBOT_BENCHMARK_CONTROLS = 'false';
// All ordinary generation/classification/embedding network traffic is forbidden.
const originalFetch = globalThis.fetch;
let externalAttempts = 0, modelAttempts = 0;
globalThis.fetch = (async (input: any, init?: any) => {
  const target = new URL(input instanceof Request ? input.url : String(input));
  if (!['localhost', '127.0.0.1', '[::1]'].includes(target.hostname)) { externalAttempts++; throw Error('External transport forbidden in local reply check'); }
  return originalFetch(input, init);
}) as typeof fetch;
const { AiSettingsService, ChatAgent } = await import('najm-chatbot');
(AiSettingsService.prototype as any).getInternal = async () => ({ isEnabled: true, provider: 'openrouter',
  apiKey: 'unused-local-transport-blocked', model: 'openai/gpt-oss-120b', useMemory: false });
(ChatAgent.prototype as any).buildModel = () => { modelAttempts++; throw Error('Generation forbidden in local reply check'); };
const { server } = await import('@sms/server');
const { chatDiagnosticsLog } = await import('../packages/server/src/modules/chat/ChatDiagnosticsLog');
const base = 'http://127.0.0.1:3103/api', year = '2026-2027';
const check = (condition: unknown, message: string) => { if (!condition) throw Error(message); };
async function login(email: string, password: string) {
  const response = await fetch(base + '/auth/login', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ email, password }) });
  check(response.ok, 'Login failed: ' + response.status);
  const body = await response.json() as any;
  const token = (body.data ?? body).accessToken;
  check(typeof token === 'string', 'Login token absent');
  return token;
}
async function mcp(token: string, name: string, args: Record<string, unknown> = {}, selectedYear = year) {
  const response = await fetch(base + '/mcp', { method: 'POST', headers: { authorization: `Bearer ${token}`, 'content-type': 'application/json',
    accept: 'application/json, text/event-stream', 'X-Academic-Year': selectedYear }, body: JSON.stringify({ jsonrpc: '2.0', id: crypto.randomUUID(), method: 'tools/call', params: { name, arguments: { ...args, academicYear: selectedYear } } }) });
  const result = await response.json() as any;
  if (!response.ok || result.error || result.result?.isError) throw Error('MCP read denied or unavailable: ' + name);
  return JSON.parse(result.result.content.find((item: any) => item.type === 'text').text);
}
const rows: Array<Record<string, unknown>> = [];
async function chat(token: string, id: string, query: string, tools: string[], verify: (text: string, outputs: any[]) => void) {
  const correlation = crypto.randomUUID(), started = performance.now();
  const response = await fetch(base + '/chat', { method: 'POST', headers: { authorization: `Bearer ${token}`, 'content-type': 'application/json',
    'X-Academic-Year': year, 'x-request-id': correlation }, body: JSON.stringify({ messages: [{ role: 'user', parts: [{ type: 'text', text: query }] }] }) });
  check(response.ok, 'Chat status: ' + id);
  const parsed = parseUiStream(await response.text()), completeMs = performance.now() - started;
  check(parsed.complete, 'Stream incomplete: ' + id);
  check(JSON.stringify(parsed.tools.map(tool => tool.name)) === JSON.stringify(tools), 'Wrong tool plan: ' + id);
  verify(parsed.text, parsed.tools.map(tool => tool.output));
  const diagnostic = chatDiagnosticsLog.find(correlation);
  check(diagnostic && diagnostic.reply?.source === 'template' && !diagnostic.reply?.error && !diagnostic.steps.length, 'Bad diagnostics: ' + id);
  check(diagnostic.routingStatus === 'disabled', 'Unexpected routing: ' + id);
  rows.push({ id, query, completeMs, tools, toolAndFactPass: true, replyLabel: diagnostic.reply?.label, generationCalls: 0 });
}

await server.listen(3103);
try {
  const password = fixture ? /SCHOOL_HISTORY_ADMIN_PASSWORD\s*[:=]\s*['"]([^'"]+)['"]/u.exec(readFileSync('.cache/finance-run.ts', 'utf8'))?.[1] : process.env.ADMIN_PASSWORD;
  const admin = await login(fixture ? 'admin@history.example.test' : process.env.ADMIN_EMAIL!, password!);
  const classes = await mcp(admin, 'classes_get_classes');
  const students = await mcp(admin, 'students_get_students');
  check(Array.isArray(classes) && Array.isArray(students), 'Invalid ground truth');
  const classQueries = ['الأقسام كاملين ديال المدرسة عطيني سميتهم.', 'l2a9sam kamlin dyal lmdrasa 3tini smiythom.'];
  for (const [i, query] of classQueries.entries()) await chat(admin, 'classes-' + i, query, ['classes_get_classes'], (text, outputs) => {
    check(outputs[0].length === classes.length, 'Wrong class scope');
    for (const c of classes) {
      check(text.includes('- ' + c.name + ':'), 'Missing class name');
      for (const section of c.sections.filter((s: any) => s.id !== null)) check(text.includes(section.name), 'Missing section name');
    }
    check(text.includes(year), 'Missing year');
  });
  const fifthQueries = ['شحال من تلميذ كاين فالقسم الخامس بوحدو؟', 'ch7al mn tilmid kayn f l9ism lkhamis bo7do?'];
  // The history fixture deliberately has no fifth class; freeze that independently.
  if (fixture) {
    check(classes.length === 1 && classes[0].name === 'History 2026-2027', 'History fixture changed');
    for (const [i, query] of fifthQueries.entries()) await chat(admin, 'unresolved-fifth-' + i, query, ['classes_get_classes', 'students_get_students'], text => {
      check(text.includes('ما قدرتش نحدد') && !text.includes('0 تلميذ'), 'Unresolved class became a zero');
    });
  }
  const daughters = ['بغيت غير النقط ديال بنتي فهاد العام.', 'bghit ghir nno9at dyal bnti f had l3am.'];
  for (const [i, query] of daughters.entries()) await chat(admin, 'admin-child-clarification-' + i, query, [], text => {
    check(text.includes('شكون كتقصد'), 'Missing child identity did not clarify');
    check(!/غياب|حضور/u.test(text), 'Grades confused with attendance');
  });
  let ownershipDenials = 0, historicalDenials = 0, populatedChildGrades = 0, linkedChildren = 0;
  if (!fixture) {
    const parents = await mcp(admin, 'parents_get_parents');
    let actor: any;
    for (const parent of parents.filter((p: any) => p.email && p.userId)) {
      const children = await mcp(admin, 'parents_get_children', { id: parent.id });
      if (children.length < 2) continue;
      for (const child of children) {
        const academic = await mcp(admin, 'student-profile_get_academic', { studentId: child.id });
        if (!academic.grades.length) continue;
        actor = { parent, children, child, academic }; break;
      }
      if (actor) break;
    }
    check(actor, 'Populated parent with linked child grades not available');
    // Reuse the already documented demo login. Never save credentials or tokens.
    let defaultPassword = process.env.DEFAULT_USER_PASSWORD?.trim();
    if (!defaultPassword) {
      const python = Bun.spawn(['python', '-c', "import zipfile,re,json; z=zipfile.ZipFile('docs/evidence/chatbot-latency/darija-20b-quality-20261009.zip'); t=z.read('harness/capture.mjs').decode(); m=re.search(r\"DEFAULT_USER_PASSWORD\\?\\.trim\\(\\)\\|\\|['\\\"]([^'\\\"]+)['\\\"]\",t); print(json.dumps(m.group(1) if m else None))"], { stdout: 'pipe', stderr: 'pipe' });
      defaultPassword = JSON.parse(await new Response(python.stdout).text()); check(await python.exited === 0, 'Demo credential source unavailable');
    }
    check(defaultPassword, 'Documented demo credential missing');
    const parentToken = await login(actor.parent.email, defaultPassword!);
    const owned = await mcp(parentToken, 'parents_get_children', { id: actor.parent.id });
    check(owned.some((c: any) => c.id === actor.child.id), 'Linked child not visible to parent');
    const truth = await mcp(parentToken, 'student-profile_get_academic', { studentId: actor.child.id });
    check(truth.grades.length === actor.academic.grades.length, 'Parent grade scope differs');
    linkedChildren = owned.length; populatedChildGrades = truth.grades.length;
    const childQueries = [`وريني النقط ديال ${actor.child.name} فهاد العام`, `werini nno9at dyal ${actor.child.name} f had l3am`];
    for (const [i, query] of childQueries.entries()) await chat(parentToken, 'parent-named-child-grades-' + i, query, ['student-profile_get_academic'], (text, outputs) => {
      check(outputs[0].grades.length === truth.grades.length, 'Wrong grade count');
      for (const g of truth.grades) {
        check(g.studentId === actor.child.id, 'Unexpected grade identity');
        check(text.includes(g.subject.name) && text.includes((g.assessment ?? g.exam).title), 'Missing subject or assessment');
        check(text.includes(`${Number(g.marksObtained)} / ${Number((g.assessment ?? g.exam).totalMarks)}`), 'Wrong mark or denominator');
      }
      check(text.includes(actor.child.name) && text.includes(year), 'Wrong child or year');
      check(!/غياب|حضور/u.test(text), 'Attendance substituted for grades');
    });
    // Do not retain a real child's name in the public question record.
    for (const row of rows) if (String(row.id).startsWith('parent-named-child')) row.query = String(row.query).replace(actor.child.name, '<owned full child name>');
    await chat(parentToken, 'parent-ambiguous-child', 'وريني نقط طفلي', [], text => check(text.includes('شكون من ولادك'), 'Multiple children did not clarify'));
    await chat(parentToken, 'parent-class-denial', classQueries[0], [], text => check(text.includes('حساب الإدارة'), 'School-wide read not refused'));
    const outsider = students.find((s: any) => !owned.some((c: any) => c.id === s.id));
    check(outsider, 'Outsider fixture unavailable');
    try { await mcp(parentToken, 'student-profile_get_academic', { studentId: outsider.id }); } catch { ownershipDenials++; }
    try { await mcp(parentToken, 'student-profile_get_academic', { studentId: actor.child.id }, '2025-2026'); } catch { historicalDenials++; }
    check(ownershipDenials === 1 && historicalDenials === 1, 'Ownership/year denial missing');
  }
  check(externalAttempts === 0 && modelAttempts === 0, 'Unexpected paid path');
  const summary = { date: '2026-10-09', fixture: fixture ? 'marked-history' : 'existing-populated-demo', privateDataRetained: false,
    savedAiSettingsChanged: false, rows, passes: rows.length, meanCompleteMs: rows.reduce((sum, row) => sum + Number(row.completeMs), 0) / rows.length,
    paidClassifierCalls: 0, paidGenerationCalls: 0, routingCalls: 0, externalAttempts, modelAttempts,
    linkedChildren, populatedChildGrades, ownershipDenials, historicalDenials };
  writeFileSync('.cache/jev-identity-live-' + (fixture ? 'history' : 'populated') + '.json', JSON.stringify(summary, null, 2), { flag: 'wx' });
  console.log(JSON.stringify({ completed: true, fixture: summary.fixture, passes: summary.passes, meanCompleteMs: summary.meanCompleteMs,
    externalAttempts, modelAttempts, linkedChildren, populatedChildGrades, ownershipDenials, historicalDenials }));
} finally { await server.stop(); }
process.exit(0);
