import {readFileSync,writeFileSync,mkdirSync,copyFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
const root='docs/evidence/chatbot-latency/',base='darija-combinations-results-20261009';
const f=JSON.parse(readFileSync('.cache/combine9-final.json','utf8'));
const truth=JSON.parse(readFileSync('.cache/combine9-private-truth.json','utf8'));
const observed=readFileSync('.cache/combine9-generations.jsonl','utf8').trim().split(/\r?\n/u).map(JSON.parse);
let generationCursor=0;
const observedCosts=new Map();
for(const row of f.rows){let cost=0;for(const step of row.diagnostics?.diagnostics?.steps??[]){const observation=observed[generationCursor++];if(!observation||step.inputTokens!==observation.usage.prompt_tokens||step.outputTokens!==observation.usage.completion_tokens)throw Error('Serial generation token alignment mismatch');cost+=observation.usage.cost;}observedCosts.set(row.id+'|'+row.arm,cost);}
if(generationCursor!==observed.length)throw Error('Unmatched generation observations');
const failed={
 '20b-coreweave-off':{4:'unrequested_student_count',5:'malformed_tool_call_despite_recovery',7:'sections_only_instead_of_expected_class_list',13:'missing_class_discovery',14:'missing_class_discovery',15:'grade_read_without_student_identity'},
 '20b-coreweave-first':{7:'sections_only_instead_of_expected_class_list',14:'missing_class_discovery',15:'grade_read_without_student_identity'},
 '20b-coreweave-router-first':{7:'sections_only_instead_of_expected_class_list',14:'arbitrary_section_and_gender_filter',16:'daughter_relation_used_as_student_name_search'}
};
const flags=(n,arm)=>{
 const x=[];if(n===7)x.push('requested_class_name_omitted');if(n===8)x.push('class_values_grounded_but_wording_requires_review');
 if(n===10&&arm.endsWith('-off'))x.push('today_read_described_as_whole_year');
 if((n===11&&!arm.endsWith('-off'))||(n===12&&arm.endsWith('-first')&&!arm.endsWith('-router-first')))x.push('upcoming_exam_read_worded_more_broadly_than_source');
 if(n===13&&arm.endsWith('-off'))x.push('claims_lookup_without_read');
 if(n===13&&arm.endsWith('-router-first'))x.push('unresolved_class_incorrectly_implies_zero_students');
 if(n===14)x.push('requested_fifth_class_not_resolved');
 if(n===15&&!arm.endsWith('-router-first'))x.push('input_error_incorrectly_presented_as_missing_tool_or_permission');
 if(n===16)x.push(arm.endsWith('-router-first')?'search_for_literal_daughter_relation_is_not_identity_resolution':'grades_question_answered_as_attendance');
 if(n===23&&arm.endsWith('-router-first'))x.push('invented_prior_context_and_internal_tool_instructions');
 if(n===24&&!arm.endsWith('-first'))x.push('wrong_answer_language');
 if(n===24&&arm.endsWith('-router-first'))x.push('wrong_answer_language');
 if(n===8&&arm==='20b-coreweave-first')x.push('english_planning_echo');
 return [...new Set(x)];
};
const identifiers=new Set();
const collect=v=>{if(!v||typeof v!=='object')return;for(const[k,x]of Object.entries(v)){if(['id','name','phone','email'].includes(k)&&typeof x==='string'&&x.length>3)identifiers.add(x);else if(x&&typeof x==='object')collect(x);}};collect(truth);
const redact=s=>{for(const x of [...identifiers].sort((a,b)=>b.length-a.length))s=s.replaceAll(x,'<fixture-record>');return s.replace(/history-[\w-]+/gu,'<fixture-id>');};
const rows=f.rows.map(r=>{
 const n=Number(r.id.slice(-2)),d=r.diagnostics?.diagnostics??{},raw=JSON.parse(readFileSync(`.cache/combine9-private-${r.id}-${r.arm}.json`,'utf8')).raw;
 const jevSelected=d.reply?.label?.startsWith('jev:')===true;
 return {caseId:r.id,arm:r.arm,query:r.query,expected:r.expected,elapsedMs:r.ms,toolPlanPass:!failed[r.arm][n],toolPlanFailure:failed[r.arm][n]??null,answerReviewFlags:flags(n,r.arm),replySource:d.reply?.source??null,replyLabel:d.reply?.label??null,replyLanguage:d.reply?.language??null,jevSelected,jevSelectedAnswerGrounded:jevSelected?true:null,answerText:redact(raw.text),tools:r.tools.map(t=>({name:t.name,outcome:t.outcome})),technicalIssues:r.technicalIssues,generationSteps:d.steps?.length??0,generationSdkEstimateUsd:r.costUsd,generationReportedUsageCostUsd:observedCosts.get(r.id+'|'+r.arm),classification:r.classifier.map(a=>({choice:a.choice,outcome:a.outcome,selected:a.selected,responseCostUsd:a.responseCostUsd??a.costUsd??null})),candidateState:d.replyPreparation?.candidateState??null,candidateTimedOut:d.replyPreparation?.timedOut??false,availableToolNames:d.replyPreparation?.availableToolNames??null};
});
const summaries=f.plan.arms.map(arm=>{const rr=rows.filter(r=>r.arm===arm),original=f.rows.filter(r=>r.arm===arm);return{arm,requests:rr.length,toolPlanPass:rr.filter(r=>r.toolPlanPass).length,averageSeconds:rr.reduce((a,r)=>a+r.elapsedMs,0)/rr.length/1000,jevAnswers:rr.filter(r=>r.jevSelected).length,modelAnswers:rr.filter(r=>r.replySource==='model').length,localWriteRefusals:rr.filter(r=>r.caseId.endsWith('21')||r.caseId.endsWith('22')).length,classifierAttempts:original.reduce((a,r)=>a+r.classifier.length,0),generationSteps:rr.reduce((a,r)=>a+r.generationSteps,0),generationSdkEstimateUsd:rr.reduce((a,r)=>a+r.generationSdkEstimateUsd,0),generationReportedUsageCostUsd:rr.reduce((a,r)=>a+r.generationReportedUsageCostUsd,0)};});
if(rows.length!==60||summaries.map(s=>s.toolPlanPass).join(',')!=='14,17,17'||rows.filter(r=>r.jevSelected).length!==8||f.savedFixtureSettingsChanged)throw Error('Result invariant failed');
for(const[p,sha]of Object.entries(f.plan.sourceHashes))if(createHash('sha256').update(readFileSync(p)).digest('hex')!==sha)throw Error('Source changed '+p);
if(observed.some(o=>o.model!=='openai/gpt-oss-20b'||o.provider!=='CoreWeave'||o.status!==200||!Number.isFinite(o.usage?.cost)))throw Error('Provider observation mismatch');
const archiveDir='.cache/combine9-public';mkdirSync(archiveDir,{recursive:true});
writeFileSync(archiveDir+'/observations.json',JSON.stringify(rows,null,2)+'\n');
writeFileSync(archiveDir+'/plan.json',JSON.stringify(f.plan,null,2)+'\n');
writeFileSync(archiveDir+'/generation-observations.json',JSON.stringify(observed.map(o=>({model:o.model,provider:o.provider,status:o.status,usage:o.usage,requestToolNames:o.requestToolNames})),null,2)+'\n');
copyFileSync('.cache/combine9-tests.log',archiveDir+'/tests.log');
for(const[p]of Object.entries(f.plan.sourceHashes)){const dest=archiveDir+'/sources/'+p.replace(/^\.cache\//u,'harness/');mkdirSync(dest.slice(0,dest.lastIndexOf('/')),{recursive:true});copyFileSync(p,dest);}
const report={date:'2026-10-09',purpose:f.plan.purpose,requests:60,summaries,groundTruth:{source:'authenticated internal MCP reads in marked local administrator fixture',academicYear:'2026-2027',students:8,teachers:0,classes:1,sections:2,todayAttendanceRecords:0,upcomingExams:0,explicitFifthClass:false,linkedChildContext:false},scoring:{type:'assistant manual tool-plan review against frozen expected intent',failuresRetainedAfterRecovery:true,unrequestedExtraCountFails:true,classListInterpretation:'Frozen classes_list intent requires class identity, not section labels alone. Native class/section terminology remains reviewable.',personalGrade:'Administrator has no linked daughter identity; clarify before reading/searching.',answerReview:'All 60 replies reviewed separately for visible grounding, scope and task errors. No aggregate native-fluency or full-answer acceptance score is claimed.'},jev:{selectedReplies:8,selectedRepliesGrounded:8,wrongAcceptedPlans:0,attempts:32,reportedResponseCostUsd:f.finalStatus.budget.knownCostUsd,unknownCosts:0,candidateTimeoutMs:3000,twoSecondAccuracyCutoff:false},generation:{model:'openai/gpt-oss-20b',provider:'CoreWeave',observedResponses:observed.length,observedUsageCostUsd:observed.reduce((a,o)=>a+o.usage.cost,0),sdkEstimatedCostUsd:f.generationCostUsd,costBasis:'OpenRouter response usage cost is observed aggregate; SDK price-table estimates differ. Embeddings are excluded. Neither is a settled monthly invoice; no extra billing experiment was run.'},limits:['20 reused assistant-authored Darija/Arabizi questions, ten paired families; not 60 independent questions.','Serial rotating order, one observation per path/question, no retries; stochastic fallback differences are not proof that ordering caused them.','Administrator fixture has eight students, zero teachers and empty current attendance/upcoming exams; no populated personal-role qualification.','Local guards/templates and unchanged Jev guard/profile 6 are included. Mode timeout is 3000ms, not default 800ms.','Saved 100-case selection and populated 24-case quality studies are different populations and are not rescored or merged.'],recommendation:{flow:'Local safe reply -> guarded Jev for supported whole-school requests -> existing router plus 20B on fallback.',status:'Conditional development recommendation, not a production-wide 20B or Jev enablement.',reason:'Hybrid paths tie at 17/20; all eight direct Jev answers grounded. Jev-first is the simpler conditional path, supported also by the saved larger development comparison; this small run establishes no universal ordering winner.',next:'Skip provably unsupported requests before paid Jev classification; repair class/section resolution and daughter-identity clarification, then recheck only the failing Darija families. Keep the current production model/settings until populated role answer quality passes.'},sourceHashes:f.plan.sourceHashes,rows,verification:{testsPassed:70,testsFailed:0,productionSourceChanged:false},cleanup:{pending:true},savedFixtureSettingsChanged:false,archive:{path:root+'darija-combinations-20261009.zip',verificationPending:true}};
writeFileSync(root+base+'.json',JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({summaries,observedGenerations:observed.length,steps:summaries.reduce((a,s)=>a+s.generationSteps,0),observedGenerationCost:report.generation.observedUsageCostUsd,jevCost:report.jev.reportedResponseCostUsd}));
