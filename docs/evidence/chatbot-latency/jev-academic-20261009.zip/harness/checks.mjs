const tasks = process.argv.includes('--final') ? [
  ['final-focused', ['bun','test','packages/server/tests/chat/SchoolAcademicReplies.test.ts','packages/server/tests/security/ChatDiagnostics.test.ts','packages/server/tests/security/ChatReadOnlyTools.test.ts']],
  ['final-lint', ['bun','run','lint']],
  ['final-typecheck', ['bun','run','typecheck']],
] : [
  ['backend', ['bun','test','packages/server/tests/chat','packages/server/tests/academicYears','packages/server/tests/ownership','packages/server/tests/security/ChatDiagnosticsPermissions.test.ts']],
  ['lint', ['bun','run','lint']],
  ['typecheck', ['bun','run','typecheck']],
  ['boundaries', ['bun','run','test:boundaries']],
];
const results=await Promise.all(tasks.map(async([name,args])=>{
  const start=performance.now(), p=Bun.spawn(args,{stdout:'pipe',stderr:'pipe'});
  const [stdout,stderr,exitCode]=await Promise.all([new Response(p.stdout).text(),new Response(p.stderr).text(),p.exited]);
  await Bun.write('.cache/jev-academic-'+name+'.log',stdout+'\n'+stderr);
  const result={name,command:args.join(' '),exitCode,elapsedMs:performance.now()-start,tests:(stderr+'\n'+stdout).match(/\d+ pass\n\s*\d+ fail/u)?.[0]};
  console.log(JSON.stringify(result));return result;
}));
await Bun.write(process.argv.includes('--final') ? '.cache/jev-academic-final-checks.json' : '.cache/jev-academic-checks.json',JSON.stringify(results,null,2));
if(results.some(r=>r.exitCode!==0))process.exit(1);
