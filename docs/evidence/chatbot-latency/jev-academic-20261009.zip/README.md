# Bounded academic replies — 2026-10-09

18/18 actual authenticated local API tool-and-fact checks pass, covering seven
reused populated-review failure questions, five drafted variants and six year/write
refusals. Three outsider and three historical academic reads deny. The actual teacher
has 44 students, four assignments (Français) and 20 assessments without any recorded
grades. Parent/student profiles each have ten grades. Average local reply is 20.069 ms.
All classification/generation/routing calls and external/model-construction attempts
are zero. This is a template/API check, not a Jev/provider/browser comparison.

School recognizes a closed subset, resolves only owned identities, executes existing
MCP tools under their guards and renders returned facts. Unknown names/filters keep
the router. Singular diagnostic quiz/subject ambiguity clarifies. Pending count means
assessments with no grades, not remaining papers in partially graded assessments.
The existing fourth-class maths plan passes eight synthetic chats with Jev off.
General Jev/20B rollout and a durable monthly budget are not enabled by this milestone.

Verification history retains the corrected harness/typecheck issues. Final focused
41 tests (32 academic + 9 security), wider 1093 backend tests and 561 script tests pass.
Final root lint/typecheck and production build pass. The owned 1,040,640,894-byte build
was removed; original Next references/tsconfig were preserved. Main app port3102
remained PID21592; owned3103 host stopped. No saved AI settings/domain rows were changed.
Actual names, IDs, credentials and raw profile payloads are not included.

Reproduction uses existing local demo records and documented fixture credentials.
From the repository root, copy harness files to .cache/jev-academic-<basename>.
Run Bun with apps/dashboard/.env.local for preflight.ts, then live.ts. Port3103 must
be free. Preflight writes an ignored private actor file used only by live.ts; remove
that private file afterwards. The credential fallback reads the retained prior demo
archive in RAM. Helpers reject nonlocal DBs and forbid paid HTTP/model construction.
checks.mjs runs wider checks; --final runs focused/security, lint/typecheck.
build.mjs requires a fresh owned output folder and restores only its type references;
remove only that verified owned folder after checking the result. Generated logs and
private actor captures are intentionally excluded here.
