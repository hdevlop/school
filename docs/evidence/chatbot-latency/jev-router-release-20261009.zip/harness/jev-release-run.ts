import 'reflect-metadata';
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { parseUiStream } from '../scripts/chatbot-roles.mjs';
import { schoolReplyLanguage } from '../packages/server/src/modules/chat/schoolReplyLanguage';
import { hasGuardedJevReply } from '../packages/server/src/modules/chat/jevQueryGuard';

const corpusPath='datasets/chatbot-latency/jev-router-release-holdout-20261009.json';
const corpus=JSON.parse(readFileSync(corpusPath,'utf8'));
const enable=process.argv.includes('--enable');
const url=new URL(process.env.DB_URL!);
if(!['localhost','127.0.0.1','[::1]'].includes(url.hostname))throw Error('Local DB required');
process.env.REDIS_URL='';process.env.NODE_ENV='development';
process.env.CHATBOT_FLOW='jev-router-20b';process.env.CHATBOT_JEV_MODE='on';
process.env.CHATBOT_BENCHMARK_CONTROLS='false';process.env.CHATBOT_MONTHLY_MICRO_USD='500000';
const final=process.argv.includes('--final-repair');
const repair=process.argv.includes('--repair');
const holdout=process.argv.includes('--holdout'),local=process.argv.includes('--local-repair');
const tag=enable?'enabled-smoke':final?'final-repair':holdout?'holdout':local?'local-repair':repair?'recheck':'';
const output=`.cache/jev-release-${tag?tag+'-':''}results.json`,privateOutput=`.cache/jev-release-${tag?tag+'-':''}private.json`;
const cases=enable?[...corpus.cases,...corpus.finalHoldout].filter((c:any)=>['release01','release09','release17','release23','release25','release28'].includes(c.id)):final?[...corpus.cases,...corpus.finalHoldout].filter((c:any)=>['release09','release15','release24','release25','release26'].includes(c.id)):holdout?corpus.finalHoldout:local?corpus.cases.filter((c:any)=>['release09','release10','release12','release18'].includes(c.id)):repair?corpus.cases.filter((c:any)=>['release04','release09','release10','release11','release12','release14','release16','release18'].includes(c.id)):corpus.cases;
const check=(ok:unknown,label:string)=>{if(!ok)throw Error(label);};
let classifierCalls=0,generationCalls=0,embeddingCalls=0,activeId='preflight';
const paidRows:Array<{id:string;kind:string;model?:string;ms:number;status:number}>=[];
const nativeFetch=globalThis.fetch;
globalThis.fetch=(async(input:any,init:any)=>{
 const target=new URL(input instanceof Request?input.url:String(input));
 if(!['localhost','127.0.0.1','[::1]'].includes(target.hostname)){
  const classification=target.pathname.endsWith('/decisions'),generation=target.pathname.endsWith('/chat/completions'),embedding=target.pathname.endsWith('/embeddings');
  check(target.hostname==='openrouter.ai'||embedding,'Unqualified external destination');
  if(classification)classifierCalls++;if(generation)generationCalls++;if(embedding)embeddingCalls++;
  check(classifierCalls<=12&&generationCalls<=40&&embeddingCalls<=60,'Frozen dispatch limit');
  const data=typeof init?.body==='string'?JSON.parse(init.body):{};
  check(!generation||data.model==='openai/gpt-oss-20b','No 120B dispatch');
  const start=performance.now(),response=await nativeFetch(input,init);
  paidRows.push({id:activeId,kind:classification?'classification':generation?'generation':'embedding',model:data.model,ms:performance.now()-start,status:response.status});
  return response;
 }
 return nativeFetch(input,init);
}) as typeof fetch;
const {AiSettingsService}=await import('najm-chatbot');
const getInternal=AiSettingsService.prototype.getInternal;
if(!enable)AiSettingsService.prototype.getInternal=async function(){const settings=await getInternal.call(this);check(settings?.provider==='openrouter'&&settings.apiKey,'Existing OpenRouter settings required');return {...settings,model:'openai/gpt-oss-20b',useMemory:false};};
const {server}=await import('@sms/server');
const {chatDiagnosticsLog}=await import('../packages/server/src/modules/chat/ChatDiagnosticsLog');
const {ChatSpendRepository}=await import('../packages/server/src/modules/chat/ChatSpendRepository');
const base='http://127.0.0.1:3103/api',year='2026-2027';
async function login(email:string,password:string){const r=await fetch(base+'/auth/login',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({email,password})});check(r.ok,'Login failed');const b=await r.json();return(b.data??b).accessToken;}
async function mcp(token:string,name:string,args:any={}){const r=await fetch(base+'/mcp',{method:'POST',headers:{authorization:`Bearer ${token}`,'content-type':'application/json',accept:'application/json, text/event-stream','X-Academic-Year':year},body:JSON.stringify({jsonrpc:'2.0',id:crypto.randomUUID(),method:'tools/call',params:{name,arguments:{...args,academicYear:year}}})});const b=await r.json();check(r.ok&&!b.error&&!b.result?.isError,'MCP failed: '+name);return JSON.parse(b.result.content.find((x:any)=>x.type==='text').text);}
function numbers(text:string){return text.match(/\d+(?:[.,]\d+)?/gu)?.map(x=>Number(x.replace(',','.')))??[];}
function countFact(text:string,value:number){return numbers(text).includes(value);}
function gradeFact(text:string,grades:any[]){return grades.length>0&&grades.every(g=>text.includes(g.subject.name)&&countFact(text,Number(g.marksObtained))&&countFact(text,Number((g.assessment??g.exam).totalMarks)));}
await server.listen(3103);
try{
 const admin=await login(process.env.ADMIN_EMAIL!,process.env.ADMIN_PASSWORD!);
 if(enable){
  const headers={authorization:`Bearer ${admin}`,'content-type':'application/json'};
  const before=await (await fetch(base+'/ai-settings',{headers})).json();
  const old=before.data??before;check(old.provider==='openrouter','Preserve provider');
  const updated=await fetch(base+'/ai-settings',{method:'PUT',headers,body:JSON.stringify({model:'openai/gpt-oss-20b'})});check(updated.ok,'Settings update');
  const after=await (await fetch(base+'/ai-settings',{headers})).json(),current=after.data??after;
  check(current.model==='openai/gpt-oss-20b'&&current.useMemory===old.useMemory&&current.systemPrompt===old.systemPrompt&&current.isEnabled===old.isEnabled,'Settings preserved');
  const envPath='apps/dashboard/.env.local';let env=readFileSync(envPath,'utf8');
  for(const [key,value]of Object.entries({CHATBOT_FLOW:'jev-router-20b',CHATBOT_JEV_MODE:'on',CHATBOT_MONTHLY_MICRO_USD:'10000000',CHATBOT_JEV_OPERATING_TIMEOUT_MS:'3000'})){
   const expression=new RegExp('^'+key+'=.*$','m');env=expression.test(env)?env.replace(expression,key+'='+value):env.trimEnd()+'\n'+key+'='+value+'\n';process.env[key]=value;
  }
  writeFileSync(envPath,env);
  writeFileSync('.cache/jev-release-enabled-config.json',JSON.stringify({savedModel:current.model,provider:current.provider,unrelatedSettingsPreserved:true,flow:process.env.CHATBOT_FLOW,jev:process.env.CHATBOT_JEV_MODE,monthlyMicroUsd:10000000,timeoutMs:3000,credentialsCaptured:false},null,2));
 }
 let password=process.env.DEFAULT_USER_PASSWORD?.trim();
 if(!password){const p=Bun.spawn(['python','-c',"import zipfile,re,json;z=zipfile.ZipFile('docs/evidence/chatbot-latency/darija-20b-quality-20261009.zip');t=z.read('harness/capture.mjs').decode();m=re.search(r\"DEFAULT_USER_PASSWORD\\?\\.trim\\(\\)\\|\\|['\\\"]([^'\\\"]+)['\\\"]\",t);print(json.dumps(m.group(1) if m else None))"],{stdout:'pipe',stderr:'pipe'});password=JSON.parse(await new Response(p.stdout).text());check(await p.exited===0&&password,'Credential source absent');}
 const students=await mcp(admin,'students_get_students'),parents=await mcp(admin,'parents_get_parents'),teachers=await mcp(admin,'teachers_get_teachers');
 let parent:any,student:any,teacher:any;
 for(const p of parents.filter((x:any)=>x.email&&x.userId)){const children=await mcp(admin,'parents_get_children',{id:p.id});if(children.length===1){const academic=await mcp(admin,'student-profile_get_academic',{studentId:children[0].id});if(academic.grades.length===10){parent={p,c:children[0],academic};break;}}}
 for(const s of students.filter((x:any)=>x.email&&x.userId)){const academic=await mcp(admin,'student-profile_get_academic',{studentId:s.id});if(academic.grades.length===10){student={s,academic};break;}}
 for(const t of teachers.filter((x:any)=>x.email&&x.userId)){const own=await mcp(admin,'teacher-profile_get_my_students',{teacherId:t.id});if(own.studentCount===44){teacher={t,own};break;}}
 check(parent&&student&&teacher,'Expected populated fixture absent');
 const tokens:any={admin,parent:await login(parent.p.email,password!),student:await login(student.s.email,password!),teacher:await login(teacher.t.email,password!)};
 const studentCount=await mcp(admin,'students_get_student_count'),teacherCount=await mcp(admin,'teachers_get_teacher_count'),classes=await mcp(admin,'classes_get_classes');
 const attendance=await mcp(tokens.parent,'student-profile_get_attendance_summary',{studentId:parent.c.id});
 const overview=await mcp(tokens.student,'student-profile_get_overview',{studentId:student.s.id});
 const ownedCount=await mcp(tokens.teacher,'students_get_student_count');check(ownedCount.count===teacher.own.studentCount&&ownedCount.count!==studentCount.count,'Owned count remains scoped');
 const pending=await mcp(tokens.teacher,'teacher-profile_get_pending_grading',{teacherId:teacher.t.id});
 const outsider=students.find((s:any)=>!teacher.own.students.some((x:any)=>x.id===s.id));check(outsider,'Outsider control absent');
 const spend=await server.container.resolve(ChatSpendRepository),budgetBefore=await spend.snapshot();
 const privateRows:any[]=[],rows:any[]=[];
 writeFileSync(`.cache/jev-release-${tag?tag+'-':''}frozen.json`,JSON.stringify({corpusSha256:createHash('sha256').update(readFileSync(corpusPath)).digest('hex'),cases:cases.map((c:any)=>({id:c.id,query:c.query,tools:c.tools,fact:c.fact,forceFallback:c.forceFallback})),maxClassificationCalls:12,maxGenerationCalls:40,maxEmbeddingCalls:60,retries:0,source:'assistant',independentNativeAcceptance:false},null,2),{flag:'wx'});
 for(const item of cases){
  activeId=item.id;const query=item.query.replace('{child}',parent.c.name).replace('{outsider}',outsider.name);
  process.env.CHATBOT_JEV_MODE=item.forceFallback?'off':'on';
  const start=performance.now(),correlation=crypto.randomUUID();
  const response=await fetch(base+'/chat',{method:'POST',headers:{authorization:`Bearer ${tokens[item.role]}`,'content-type':'application/json','X-Academic-Year':year,'x-request-id':correlation},body:JSON.stringify({messages:[{role:'user',parts:[{type:'text',text:query}]}]})});
  const parsed=parseUiStream(await response.text()),diagnostics=chatDiagnosticsLog.find(correlation);
  const tools=parsed.tools.map((t:any)=>t.name),strictToolPass=JSON.stringify(tools)===JSON.stringify(item.tools);
  const toolPass=JSON.stringify([...tools].sort())===JSON.stringify([...item.tools].sort())
    || item.fact==='owned-student-count'&&JSON.stringify(tools)==='["students_get_student_count"]';
  let factPass=false;const text=parsed.text;
  if(item.fact==='student-count')factPass=countFact(text,studentCount.count);
  if(item.fact==='teacher-count')factPass=countFact(text,teacherCount.count);
  if(item.fact==='both-counts')factPass=countFact(text,studentCount.count)&&countFact(text,teacherCount.count);
  if(item.fact==='class-names')factPass=classes.every((c:any)=>text.includes(c.name));
  if(item.fact==='child-grades')factPass=gradeFact(text,parent.academic.grades);
  if(item.fact==='own-grades')factPass=gradeFact(text,student.academic.grades);
  if(item.fact==='child-attendance')factPass=[attendance.present,attendance.absent,attendance.late,attendance.total].every(n=>countFact(text,n));
  if(item.fact==='own-placement')factPass=text.includes(overview.student.class.name)&&text.includes(overview.student.section.name);
  if(item.fact==='owned-student-count')factPass=countFact(text,teacher.own.studentCount);
  if(item.fact==='pending-assessments')factPass=countFact(text,pending.pendingCount);
  if(item.fact==='write-refusal')factPass=/ما.*(?:نقدر|يمكن)|لا.*(?:يمكن|أستطيع)|لوحة التحكم/u.test(text);
  if(item.fact==='year-refusal')factPass=/العام.*الحالي|العام.*النشط|هاد العام|السنة.*الحالية/u.test(text)&&/غير|فقط|ما/u.test(text);
  if(item.fact==='scope-refusal')factPass=text.includes('المسموح');
  const failures=Boolean(parsed.errors?.length||parsed.failedToolCalls||diagnostics?.toolFailures?.length||diagnostics?.reply?.error||parsed.messageMetadata?.schoolReplyOutcome==='unavailable');
  const languagePass=schoolReplyLanguage(query)!=='ary'||/\p{Script=Arabic}/u.test(text)&&!/<\||\b(?:commentary|tool_call|assistant channel)\b|^(?:Need to|We need|The user|Let me|Let's)/iu.test(text);
  const calls=paidRows.filter(r=>r.id===item.id);
  const row={id:item.id,role:item.role,family:item.family,query:item.query,strictToolPass,toolPass,factPass,languagePass,complete:parsed.complete,failures,pass:toolPass&&factPass&&languagePass&&parsed.complete&&!failures,tools,reply:diagnostics?.reply,jev:diagnostics?.jev,classificationCalls:calls.filter(c=>c.kind==='classification').length,generationCalls:calls.filter(c=>c.kind==='generation').length,completeMs:performance.now()-start,guarded:hasGuardedJevReply(query)};
  rows.push(row);privateRows.push({id:item.id,query,parsed,diagnostics});
  writeFileSync(privateOutput,JSON.stringify(privateRows,null,2));
  writeFileSync(output,JSON.stringify({source:'assistant',independentNativeAcceptance:false,rows,passes:rows.filter(r=>r.pass).length,classificationCalls:classifierCalls,generationCalls,embeddingCalls,paidRows,budgetBefore,budgetAfter:await spend.snapshot(),meanCompleteMs:rows.reduce((s,r)=>s+r.completeMs,0)/rows.length,savedSettingsChanged:enable},null,2));
  console.log(JSON.stringify({id:item.id,pass:row.pass,tools,reply:diagnostics?.reply?.label,classification:row.classificationCalls,generation:row.generationCalls,ms:Math.round(row.completeMs)}));
 }
 const result={source:'assistant',independentNativeAcceptance:false,rows,passes:rows.filter(r=>r.pass).length,classificationCalls:classifierCalls,generationCalls,embeddingCalls,paidRows,budgetBefore,budgetAfter:await spend.snapshot(),meanCompleteMs:rows.reduce((s,r)=>s+r.completeMs,0)/rows.length,savedSettingsChanged:enable};
 writeFileSync(output,JSON.stringify(result,null,2));writeFileSync(privateOutput,JSON.stringify(privateRows,null,2));
 console.log(JSON.stringify({...result,rows:undefined,paidRows:undefined}));
}finally{await server.stop();}
process.exit(0);
