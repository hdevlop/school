import {readFileSync,writeFileSync} from 'node:fs';
const initial={source:'assistant',independentNativeAcceptance:false,completedChats:20,originalStrictPasses:12,classificationCalls:7,generationCalls:15,embeddingCalls:null,captureLimitation:'The initial harness failed during summary construction after completing all 20 chats; full answer capture was not retained. Counts/scores below come from emitted per-case summaries, not reconstructed answers.',
 rows:[['01',true,712],['02',true,1522],['03',true,437],['04',false,729],['05',true,406],['06',true,407],['07',true,382],['08',true,3310],['09',false,1820],['10',false,1681],['11',false,1605],['12',false,2026],['13',true,1830],['14',false,1623],['15',false,23],['16',false,833],['17',true,6],['18',true,2029],['19',true,25],['20',true,10]].map(([id,pass,ms])=>({id:'release'+id,pass,roundedCompleteMs:ms}))};
writeFileSync('.cache/jev-release-initial-summary.json',JSON.stringify(initial,null,2));
const original=JSON.parse(readFileSync('.cache/jev-release-holdout-results.json','utf8'));
const rows=original.rows.map(row=>{
 if(['release23','release27'].includes(row.id))return {...row,toolPass:true,pass:row.factPass&&row.languagePass&&row.complete&&!row.failures,auditReason:row.id==='release23'?'Both independent read tools executed, in a different valid order.':'Authorized teacher-scoped student count is a valid alternative; authenticated MCP confirms 44 owned vs 103 school-wide.'};
 return row;
});
writeFileSync('.cache/jev-release-holdout-audit.json',JSON.stringify({originalStrictPasses:original.passes,auditedPasses:rows.filter(r=>r.pass).length,meanCompleteMs:original.meanCompleteMs,postDispatchScorerChanges:true,providerCallsAdded:0,rows},null,2));
