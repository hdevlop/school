import {readFileSync,writeFileSync,existsSync} from 'node:fs';
import {resolve} from 'node:path';
import {spawnSync} from 'node:child_process';
const root=process.cwd(),dist=resolve(root,'apps/dashboard/.next-jev-release-check');
if(!dist.startsWith(resolve(root,'apps/dashboard')+'\\')||existsSync(dist))throw Error('Fresh owned build path required');
const paths=['apps/dashboard/next-env.d.ts','apps/dashboard/tsconfig.json'];
const originals=paths.map(p=>readFileSync(p));
let exit;
try{const result=spawnSync('bun',['run','build'],{env:{...process.env,NAJM_NEXT_DIST_DIR:'.next-jev-release-check'},stdio:'inherit'});exit=result.status??1;}
finally{paths.forEach((p,i)=>writeFileSync(p,originals[i]));}
writeFileSync('.cache/jev-release-build-result.json',JSON.stringify({exitCode:exit,dist:'apps/dashboard/.next-jev-release-check',generatedConfigRestored:paths},null,2));
process.exit(exit);
