import {writeFileSync}from'node:fs';
const base='http://127.0.0.1:3102/api';
const r=await fetch(base+'/auth/login',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({email:process.env.ADMIN_EMAIL,password:process.env.ADMIN_PASSWORD})});const b=await r.json(),token=(b.data??b).accessToken;
const data=await(await fetch(base+'/chat-diagnostics?limit=1',{headers:{authorization:'Bearer '+token}})).json();const d=(data.data??data)[0];
const result={jev:d?.jev??null,paid:d?.paid??null,reply:d?.reply??null,tools:d?.tools.map(t=>({name:t.name,outcome:t.outcome}))};
writeFileSync('.cache/jev-release-main-state.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result));
