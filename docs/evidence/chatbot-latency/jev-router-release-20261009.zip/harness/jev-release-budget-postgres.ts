import 'reflect-metadata';
import { writeFileSync } from 'node:fs';
import { sql } from 'drizzle-orm';
const url=new URL(process.env.DB_URL!);
if(!['localhost','127.0.0.1','[::1]'].includes(url.hostname))throw Error('Fixture DB required');
url.pathname='/school_history_test';process.env.DB_URL=url.toString();
const {db}=await import('../packages/server/src/database/db');
const {ChatSpendRepository}=await import('../packages/server/src/modules/chat/ChatSpendRepository');
const now=new Date('1999-11-15T00:00:00Z'),next=new Date('1999-12-01T00:00:00Z');
const r=new ChatSpendRepository();r.db=db;
const check=(ok:unknown,message:string)=>{if(!ok)throw Error(message);};
await r.snapshot(now);
check((await r.snapshot(now)).usedMicroUsd===0&&(await r.snapshot(next)).usedMicroUsd===0,'Fresh test months required');
try{
 const compare=await r.reserve('generation',6000,10000,now);check(compare,'Numeric comparison must admit 6000 below 10000');
 await r.settle(compare!,0);await r.settle(compare!,0);check((await r.snapshot(now)).usedMicroUsd===0,'Idempotent settlement');
 const rows=await Promise.all(Array.from({length:12},()=>r.reserve('classification',2000,10000,now)));
 const accepted=rows.filter((v):v is NonNullable<typeof v>=>v!==null);check(accepted.length===5,'Atomic reservations across concurrent calls');
 const restarted=new ChatSpendRepository();restarted.db=db;check((await restarted.snapshot(now)).usedMicroUsd===10000,'Unknown charges survive repository restart');
 check(await restarted.reserve('embedding',1,10000,now)===null,'Shared allowance exhausted');
 await restarted.settle(accepted[0],0.000001);check((await restarted.snapshot(now)).usedMicroUsd===8001,'Known cost releases only its reservation');
 const replacement=await restarted.reserve('generation',1999,10000,now);check(replacement,'Released allowance reusable');
 await restarted.settle(replacement!,0.02);check((await restarted.snapshot(now)).usedMicroUsd===28001,'Known overrun is fully charged');
 check(await restarted.reserve('classification',1,10000,now)===null,'Overrun blocks further dispatch');
 check(await restarted.reserve('classification',1,10000,next)!==null,'New UTC month has independent allowance');
 const result={fixture:'school_history_test',numericComparison:true,concurrentAttempts:12,accepted:5,restartPreservedUnknown:true,allKindsShared:true,idempotentSettlement:true,knownOverrunCharged:true,monthlyReset:true,paidCalls:0};
 writeFileSync('.cache/jev-release-budget-postgres.json',JSON.stringify(result,null,2),{flag:'wx'});console.log(JSON.stringify(result));
}finally{
 await db.transaction(async tx=>{
  await tx.execute(sql`delete from school_chat_spend_attempt where month in ('1999-11','1999-12')`);
  await tx.execute(sql`delete from school_chat_spend_month where month in ('1999-11','1999-12')`);
 });
}
process.exit(0);
