import 'reflect-metadata';
process.env.CHATBOT_PROVIDER_OBSERVER_FILE = 'C:/Users/pc/Desktop/school/.cache/quality20b-generation.jsonl';
process.env.CHATBOT_PROVIDER_OBSERVER_TOOL_NAMES = 'true';
await import('../scripts/chatbot-provider-observer.mjs');
import { AiSettingsService, CHATBOT_CONFIG } from 'najm-chatbot';
// Process-local overrides: no AI-settings PUT and no change to the school's saved model.
const original = AiSettingsService.prototype.getInternal;
AiSettingsService.prototype.getInternal = async function (...args: Parameters<typeof original>) {
  const settings = await original.apply(this, args);
  if (settings && settings.model !== 'openai/gpt-oss-120b') throw Error('Saved school model changed');
  return settings ? { ...settings, model: 'openai/gpt-oss-20b', useMemory: false } : settings;
};
process.env.CHATBOT_JEV_MODE = 'off';
process.env.CHATBOT_BENCHMARK_CONTROLS = 'false';
process.env.REDIS_URL = '';
const { server } = await import('@sms/server');
await server.listen(3103);
const config = server.container.get(CHATBOT_CONFIG) as any;
config.openrouter = { ...config.openrouter, provider: { only: ['coreweave'], allow_fallbacks: false, require_parameters: true } };
console.log(JSON.stringify({ port: 3103, roleModel: 'openai/gpt-oss-20b', provider: 'coreweave-only', savedSettingsChanged: false }));
