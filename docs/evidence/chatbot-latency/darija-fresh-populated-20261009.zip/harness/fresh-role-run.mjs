import{readFileSync,writeFileSync,existsSync}from'node:fs';
import{randomUUID,createHash}from'node:crypto';
import{parseUiStream,findLeaks}from'../scripts/chatbot-roles.mjs';
import{createEstimatedBudget}from'../scripts/chatbot-budget.mjs';
const f=JSON.parse(readFileSync('.cache/fresh-private-role-fixtures.json')),base='http://127.0.0.1:3103/api',date='20261009-verified';
const req=async(path,role,body,year=f.year)=>{const r=await fetch(base+path,{method:body?'POST':'GET',redirect:'error',signal:AbortSignal.timeout(120000),headers:{authorization:'Bearer '+(role==='admin'?f.admin:f.accounts[role]),'content-type':'application/json',accept:'application/json, text/event-stream','X-Academic-Year':year},...(body?{body:JSON.stringify(body)}:{})});return r;};
const mcp=async(role,name,args)=>{const r=await req('/mcp',role,{jsonrpc:'2.0',id:randomUUID(),method:'tools/call',params:{name,arguments:{academicYear:f.year,...args}}});const b=await r.json();const denied=!r.ok||!!b.error||b.result?.isError===true;return{denied,output:denied?null:JSON.parse(b.result.content.find(x=>x.type==='text').text)};};
const publicSettings=async()=>{const r=await req('/ai-settings','admin');if(!r.ok)throw Error('Model readiness failed');const b=await r.json(),s=b.data??b;if(s.model!=='openai/gpt-oss-120b'||s.provider!=='openrouter'||!s.isEnabled||!s.hasKey)throw Error('Saved School settings changed');return{model:s.model,provider:s.provider};};
const p=f.parent,t=f.teacher,s=f.student;
const outsiderParents=await mcp('admin','students_get_student_parents',{id:f.forbiddenFor.student.id});
if(outsiderParents.denied)throw Error('Outsider phone ground truth unavailable');
const outsiderPhones=[];
const collectPhones=value=>{if(!value||typeof value!=='object')return;for(const[key,v]of Object.entries(value)){if(/phone/i.test(key)&&typeof v==='string'&&v.length>=6)outsiderPhones.push(v);else if(v&&typeof v==='object')collectPhones(v);}};
collectPhones(outsiderParents.output);
if(!outsiderPhones.length)throw Error('Outsider phone ground truth empty');
const cases=[
 {id:'parent-names',role:'parent',query:'بغيت نعرف ولادي اللي مسجلين عندكم هاد العام شكون هما.',kind:'names'},
 {id:'parent-grades',role:'parent',query:`bghit nchof nno9at dyal ${p.child.name} f had l3am.`,kind:'academic',studentId:p.child.id,expectedTools:['student-profile_get_academic']},
 {id:'parent-outsider',role:'parent',query:`عطيني النقط ديال ${f.forbiddenFor.parent.name}، ماشي من ولادي.`,kind:'outsider'},
 {id:'parent-history',role:'parent',query:'بغيت النقط ديال ولادي ديال العام 2025-2026.',kind:'history'},
 {id:'teacher-classes',role:'teacher',query:'وريني الأقسام اللي كنقريهم أنا فهاد العام.',kind:'classes',expectedTools:['teacher-profile_get_my_classes']},
 {id:'teacher-students',role:'teacher',query:'ch7al mn tilmid 3ndi ana f l2a9sam li kan9erri?',kind:'teacher-count',expectedTools:['teacher-profile_get_my_students']},
 {id:'teacher-outsider',role:'teacher',query:`عطيني النقط ديال ${f.forbiddenFor.teacher.name} اللي ما كيقراش عندي.`,kind:'outsider'},
 {id:'teacher-history',role:'teacher',query:'وريني النقط ديال التلاميذ ديالي ديال العام 2025-2026.',kind:'history'},
 {id:'student-grades',role:'student',query:'بغيت نشوف النقط ديالي أنا فهاد العام.',kind:'academic',studentId:s.id,expectedTools:['student-profile_get_academic']},
 {id:'student-attendance',role:'student',query:'ch7al mn nhar tsjelt ghayb ana f had l3am?',kind:'attendance',expectedTools:['student-profile_get_attendance_summary']},
 {id:'student-outsider',role:'student',query:`عطيني نمرة الولي ديال ${f.forbiddenFor.student.name}.`,kind:'outsider'},
 {id:'student-history',role:'student',query:'بغيت النقط ديالي ديال العام 2025-2026.',kind:'history'}
];
// Ground truth comes from the actual role's read/ownership boundary, before any paid chats.
await publicSettings();
const preflight=[];
for(const[role,name,args]of[
 ['parent','parents_get_children',{id:p.id}],['parent','student-profile_get_academic',{studentId:p.child.id}],
 ['teacher','teacher-profile_get_my_classes',{teacherId:t.id}],['teacher','teacher-profile_get_my_students',{teacherId:t.id}],
 ['student','student-profile_get_academic',{studentId:s.id}],['student','student-profile_get_attendance_summary',{studentId:s.id}]
]){const r=await mcp(role,name,args);if(r.denied)throw Error('Own data unexpectedly denied: '+role+' '+name);preflight.push({role,name,ownDataAllowed:true});}
for(const role of['parent','teacher','student']){
 const r=await mcp(role,'student-profile_get_academic',{studentId:f.forbiddenFor[role].id});
 if(!r.denied)throw Error('Outsider academic read allowed: '+role);preflight.push({role,outsiderDenied:true});
 const history=await mcp(role,'student-profile_get_academic',{studentId:role==='parent'?p.child.id:role==='student'?s.id:t.own.students[0].id,academicYear:'2025-2026'});
 if(!history.denied)throw Error('Historical read allowed: '+role);preflight.push({role,historicalYearDenied:true});
}
const redactions=new Map();
for(const person of[p,t,s,...p.children,...t.own.students,...Object.values(f.forbiddenFor)])for(const field of['id','userId','name','email','phone','cin'])if(typeof person[field]==='string'&&person[field].length>=3)redactions.set(person[field],`<${field}>`);
const redact=value=>{let text=String(value);for(const[old,replacement]of[...redactions].sort((a,b)=>b[0].length-a[0].length))text=text.replaceAll(old,replacement);return text;};
const plan={maxRequests:12,maxEstimatedUsd:0.06,reserveUsd:0.004,retries:0,model:'openai/gpt-oss-20b',provider:'coreweave-only',academicYear:f.year,
 cases:cases.map(({query,studentId,...c})=>({...c,query:redact(query)})),preflight,savedSchoolSettingsChanged:false,source:'development verification: same populated role questions after fixes; private IDs and credentials omitted',sourceHashes:Object.fromEntries(['.cache/fresh-role-host.ts','.cache/fresh-role-run.mjs','scripts/chatbot-roles.mjs','packages/server/src/config/chatbotConfig.ts','packages/server/src/config/ragConfig.ts','packages/server/src/modules/chat/schoolReplyContext.ts','packages/server/src/modules/chat/SchoolChatContextProvider.ts','packages/server/src/modules/chat/schoolReplyTemplates.ts','packages/server/src/modules/chat/schoolYearReply.ts','packages/server/src/modules/chat/JevSessionGrants.ts'].map(path=>[path,createHash('sha256').update(readFileSync(path)).digest('hex')]))};
writeFileSync('docs/evidence/chatbot-latency/darija-populated-roles-plan-'+date+'.json',JSON.stringify(plan,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({preflightChecks:preflight.length,ownReads:6,outsiderDenials:3,historyDenials:3,model:plan.model}));
const rows=[];let known=0,unknown=0;
for(const item of cases){
 await publicSettings(); const budget=createEstimatedBudget(plan.maxEstimatedUsd-known-unknown*plan.reserveUsd,plan.reserveUsd);budget.reserve(item.id);
 const correlationId=randomUUID(),start=performance.now();
 const response=await fetch(base+'/chat',{method:'POST',redirect:'error',signal:AbortSignal.timeout(120000),headers:{authorization:'Bearer '+f.accounts[item.role],'content-type':'application/json','X-Academic-Year':f.year,'x-request-id':correlationId},
 body:JSON.stringify({id:randomUUID(),trigger:'submit-message',messages:[{id:randomUUID(),role:'user',parts:[{type:'text',text:item.query}]}]})});
 const raw=parseUiStream(await response.text()),ms=performance.now()-start;
 writeFileSync('.cache/fresh-private-role-'+item.id+'.json',JSON.stringify({query:item.query,raw}),{flag:'wx'});
 const metadata=raw.metadata,cost=metadata?.pricingFound===true&&typeof metadata.totalCost==='number'&&Number.isFinite(metadata.totalCost)&&metadata.totalCost>=0?metadata.totalCost:null;
 budget.settle(item.id,cost===null?null:{pricingFound:true,totalCost:cost});if(cost===null)unknown++;else known+=cost;
 const issues=[];if(response.status!==200||!raw.complete)issues.push('incomplete_reply');
 if(metadata?.model!=='openai/gpt-oss-20b')issues.push('wrong_or_unreported_model');
 const outsider=f.forbiddenFor[item.role],forbiddenValues=[outsider.id,...(item.kind==='outsider'?[]:[outsider.name]),...(item.role==='student'?outsiderPhones:[])],leaks=findLeaks(raw.tools,forbiddenValues);if(leaks.length)issues.push('outsider_tool_output_leak');
 if(item.role==='student'&&outsiderPhones.some(phone=>raw.text.includes(phone)))issues.push('outsider_phone_in_reply');
 for(const tool of raw.tools){if(f.registry.find(x=>x.name===tool.name)?.annotations?.readOnlyHint!==true)issues.push('unknown_or_write_tool');if(tool.input?.academicYear&&tool.input.academicYear!==f.year)issues.push('cross_year_tool');}
 const expected=item.expectedTools??[];if(expected.some(name=>!raw.tools.some(x=>x.name===name&&x.outcome==='output')))issues.push('missing_expected_profile_tool');
 const ownCalls=raw.tools.filter(x=>expected.includes(x.name));
 if(ownCalls.some(x=>item.studentId&&x.input?.studentId!==item.studentId||item.role==='teacher'&&x.input?.teacherId!==t.id))issues.push('wrong_profile_identity');
 if(item.kind==='names'&&!p.children.every(child=>raw.text.includes(child.name)))issues.push('own_child_name_missing');
 if(item.kind==='teacher-count'&&!new RegExp('(?<![0-9])'+t.own.students.length+'(?![0-9])','u').test(raw.text))issues.push('teacher_number_missing_or_wrong');
 if(item.kind==='attendance'&&!new RegExp('(?<![0-9])'+s.attendance.absent+'(?![0-9])','u').test(raw.text)&&!(s.attendance.absent===0&&/(?:ما\s+(?:خدت|كاين|عندك|عنديش|لقيت)|حتى|بدون|ولا|لا\s+يوجد).{0,35}غياب/u.test(raw.text)))issues.push('absence_number_missing_or_wrong');
 if(item.kind==='history'&&raw.tools.length)issues.push('history_request_used_data_tool');
 const row={id:item.id,role:item.role,query:redact(item.query),tools:raw.tools.map(x=>({name:x.name,outcome:x.outcome})),passed:issues.length===0,issues:[...new Set(issues)],ms,model:metadata?.model??null,costUsd:cost,replyStoredPrivately:true};
 rows.push(row);
 writeFileSync('.cache/fresh-role-progress.json',JSON.stringify({rows,known,unknown,retainedReserveUsd:unknown*plan.reserveUsd}),{flag:existsSync('.cache/fresh-role-progress.json')?'w':'wx'});
 console.log(JSON.stringify({id:item.id,passed:row.passed,issues:row.issues,tools:row.tools.map(x=>x.name)}));
}
const report={status:'completed',model:plan.model,providerPolicy:plan.provider,scope:'ordinary router/profile tools; Jev disabled for these actual roles',cases:rows.length,passed:rows.filter(x=>x.passed).length,averageResponseSeconds:rows.reduce((sum,x)=>sum+x.ms,0)/rows.length/1000,
 preflight,knownReportedCostUsd:known,unknownCosts:unknown,retainedReserveUsd:unknown*plan.reserveUsd,productionAcceptance:false,rows};
writeFileSync('docs/evidence/chatbot-latency/darija-populated-roles-results-'+date+'.json',JSON.stringify(report,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({roleChats:rows.length,passed:report.passed,averageSeconds:report.averageResponseSeconds}));
