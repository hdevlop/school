# Personal reply and original tool failure checkpoint - 2026-10-09

23/23 authenticated local API tool-and-fact checks pass: 11 reused failure
questions, 5 drafted variants, 7 controls. Average 20.75 ms is local template/API
timing, not a provider/browser benchmark. Three outsider and three historical
direct MCP reads deny. Zero paid classifier, generation or routing calls;
external fetch and model construction were forbidden. Saved AI settings and
domain records were not changed. Private names, IDs, answers and tokens are absent.

Nine separate published SDK/MCP scripted scenarios exercise malformed, missing,
unoffered and denied calls plus one valid call. Eight rejected cases execute no
controller reads; the valid case executes one. These are synthetic contract tests,
not live Jev/OSS20B selection accuracy. Failure notices and fixed diagnostic
summaries persist after a later successful answer and benchmark scoring records
tool_attempt_failed. Clean streams remain unchanged; cancellation adds no notice.

Verification: 1131 backend regressions, 562 scripts/boundary checks, 48 final
focused checks, root lint/typecheck and isolated production build pass. Initial
cancellation and minimal diagnostic fixture failures were fixed and rechecked;
initial and final verification summaries are retained. The owned 1,040,860,577-byte
build was removed. Original Next references, tsconfig and app were preserved.

Reproduce in the same School checkout and populated local demo DB: extract the
four harness files to .cache, ensure port 3103 is unused, and run
bun --env-file=apps/dashboard/.env.local .cache/jev-final-preflight.ts
bun --env-file=apps/dashboard/.env.local .cache/jev-final-live.ts
The first command creates an ignored private actor capture; delete it afterward.
The second requires the original populated actor/grade counts and the existing
documented demo credential (DEFAULT_USER_PASSWORD or retained prior quality ZIP).
No credential is embedded here. These harnesses temporarily override settings in
RAM and fail if any paid model is attempted; they do not qualify ordinary Jev.
Run checks.mjs --recheck, checks.mjs --final, checks.mjs --boundaries sequentially,
then the build harness. Remove its owned build after checking the absolute path.

Source snapshots and patch contain only this checkpoint's School changes.
manifest.json gives byte counts and SHA-256 for every other entry. ZIP CRCs,
hashes, source bytes, document links and sensitive-value absence were checked.
Next: a small unseen Darija development holdout for supported Jev plans and
selective OSS20B fallback, ordinary-chat integration and durable $10/month guard.
General Jev remains off; saved fallback configuration remains unchanged.
