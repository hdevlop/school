import 'reflect-metadata';
import { readFileSync, writeFileSync } from 'node:fs';
import { parseUiStream } from '../scripts/chatbot-roles.mjs';

const fixture = process.argv.includes('--history');
const url = new URL(process.env.DB_URL!);
if (!['localhost', '127.0.0.1', '[::1]'].includes(url.hostname)) throw Error('Local data only');
if (fixture) url.pathname = '/school_history_test';
process.env.DB_URL = url.toString(); process.env.REDIS_URL = ''; process.env.NODE_ENV = 'development';
process.env.CHATBOT_JEV_MODE = 'off'; process.env.CHATBOT_BENCHMARK_CONTROLS = 'false';
// All ordinary generation/classification/embedding network traffic is forbidden.
const originalFetch = globalThis.fetch;
let externalAttempts = 0, modelAttempts = 0;
globalThis.fetch = (async (input: any, init?: any) => {
  const target = new URL(input instanceof Request ? input.url : String(input));
  if (!['localhost', '127.0.0.1', '[::1]'].includes(target.hostname)) { externalAttempts++; throw Error('External transport forbidden in local reply check'); }
  return originalFetch(input, init);
}) as typeof fetch;
const { AiSettingsService, ChatAgent } = await import('najm-chatbot');
(AiSettingsService.prototype as any).getInternal = async () => ({ isEnabled: true, provider: 'openrouter',
  apiKey: 'unused-local-transport-blocked', model: 'openai/gpt-oss-120b', useMemory: false });
(ChatAgent.prototype as any).buildModel = () => { modelAttempts++; throw Error('Generation forbidden in local reply check'); };
const { server } = await import('@sms/server');
const { chatDiagnosticsLog } = await import('../packages/server/src/modules/chat/ChatDiagnosticsLog');
const base = 'http://127.0.0.1:3103/api', year = '2026-2027';
const check = (condition: unknown, message: string) => { if (!condition) throw Error(message); };
async function login(email: string, password: string) {
  const response = await fetch(base + '/auth/login', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ email, password }) });
  check(response.ok, 'Login failed: ' + response.status);
  const body = await response.json() as any;
  const token = (body.data ?? body).accessToken;
  check(typeof token === 'string', 'Login token absent');
  return token;
}
async function mcp(token: string, name: string, args: Record<string, unknown> = {}, selectedYear = year) {
  const response = await fetch(base + '/mcp', { method: 'POST', headers: { authorization: `Bearer ${token}`, 'content-type': 'application/json',
    accept: 'application/json, text/event-stream', 'X-Academic-Year': selectedYear }, body: JSON.stringify({ jsonrpc: '2.0', id: crypto.randomUUID(), method: 'tools/call', params: { name, arguments: { ...args, academicYear: selectedYear } } }) });
  const result = await response.json() as any;
  if (!response.ok || result.error || result.result?.isError) throw Error('MCP read denied or unavailable: ' + name);
  return JSON.parse(result.result.content.find((item: any) => item.type === 'text').text);
}
const rows: Array<Record<string, unknown>> = [];
async function chat(token: string, id: string, query: string, tools: string[], verify: (text: string, outputs: any[]) => void) {
  const correlation = crypto.randomUUID(), started = performance.now();
  const response = await fetch(base + '/chat', { method: 'POST', headers: { authorization: `Bearer ${token}`, 'content-type': 'application/json',
    'X-Academic-Year': year, 'x-request-id': correlation }, body: JSON.stringify({ messages: [{ role: 'user', parts: [{ type: 'text', text: query }] }] }) });
  check(response.ok, 'Chat status: ' + id);
  const parsed = parseUiStream(await response.text()), completeMs = performance.now() - started;
  check(parsed.complete, 'Stream incomplete: ' + id);
  check(JSON.stringify(parsed.tools.map(tool => tool.name)) === JSON.stringify(tools), 'Wrong tool plan: ' + id);
  verify(parsed.text, parsed.tools.map(tool => tool.output));
  const diagnostic = chatDiagnosticsLog.find(correlation);
  check(diagnostic && diagnostic.reply?.source === 'template' && !diagnostic.reply?.error && !diagnostic.steps.length, 'Bad diagnostics: ' + id);
  check(diagnostic.routingStatus === 'disabled', 'Unexpected routing: ' + id);
  rows.push({ id, query, completeMs, tools, toolAndFactPass: true, replyLabel: diagnostic.reply?.label, generationCalls: 0 });
}

await server.listen(3103);
try {
  const admin = await login(process.env.ADMIN_EMAIL!, process.env.ADMIN_PASSWORD!);
    let defaultPassword = process.env.DEFAULT_USER_PASSWORD?.trim();
    if (!defaultPassword) {
      const python = Bun.spawn(['python', '-c', "import zipfile,re,json; z=zipfile.ZipFile('docs/evidence/chatbot-latency/darija-20b-quality-20261009.zip'); t=z.read('harness/capture.mjs').decode(); m=re.search(r\"DEFAULT_USER_PASSWORD\\?\\.trim\\(\\)\\|\\|['\\\"]([^'\\\"]+)['\\\"]\",t); print(json.dumps(m.group(1) if m else None))"], { stdout: 'pipe', stderr: 'pipe' });
      defaultPassword = JSON.parse(await new Response(python.stdout).text()); check(await python.exited === 0, 'Demo credential source unavailable');
    }
    check(defaultPassword, 'Documented demo credential missing');

  const parents = await mcp(admin, 'parents_get_parents');
  const teachers = await mcp(admin, 'teachers_get_teachers');
  const students = await mcp(admin, 'students_get_students');
  let parent: any, teacher: any, student: any;
  for (const p of parents.filter((p:any)=>p.email&&p.userId)) {
    const children = await mcp(admin,'parents_get_children',{id:p.id});
    for(const c of children) {
      const academic=await mcp(admin,'student-profile_get_academic',{studentId:c.id});
      if(academic.grades.some((g:any)=>g.subject?.code==='MATH' && /diagnostic/iu.test(g.assessment?.title??''))) {parent={p,c,children,academic};break;}
    }
    if(parent)break;
  }
  for(const t of teachers.filter((t:any)=>t.email&&t.userId)) {
    const classes=await mcp(admin,'teacher-profile_get_my_classes',{teacherId:t.id});
    const pending=await mcp(admin,'teacher-profile_get_pending_grading',{teacherId:t.id});
    if(pending.pendingCount>0) {teacher={t,classes,pending};break;}
  }
  for(const s of students.filter((s:any)=>s.email&&s.userId)) {
    const academic=await mcp(admin,'student-profile_get_academic',{studentId:s.id});
    if(academic.grades.some((g:any)=>g.subject?.code==='MATH'&&/diagnostic/iu.test(g.assessment?.title??''))) {student={s,academic};break;}
  }
  check(parent&&teacher&&student,'Populated actors missing');
  writeFileSync('.cache/jev-final-actors.json',JSON.stringify({parent,teacher,student}),{flag:'wx'});
  console.log(JSON.stringify({parentGrades:parent.academic.grades.map((g:any)=>({subject:{name:g.subject.name,code:g.subject.code},assessment:{title:g.assessment?.title,type:g.assessment?.type},exam:g.exam})),teacherAssignments:teacher.classes.classes.map((c:any)=>({subject:{name:c.subject.name,code:c.subject.code}})),teacherPending:teacher.pending.pendingCount,pendingShape:Object.keys(teacher.pending.pendingAssessments[0]),studentGradeCount:student.academic.grades.length}));
}finally{await server.stop();}
process.exit(0);
