const tasks = process.argv.includes('--final') ? [
  ['final-focused', ['bun','test','packages/server/tests/chat/SchoolPersonalReplies.test.ts','packages/server/tests/chat/SchoolToolDispatch.test.ts','packages/server/tests/chat/SchoolToolFailures.test.ts','packages/server/tests/chat/SchoolChatResponse.test.ts','packages/server/tests/security/ChatDiagnostics.test.ts','packages/server/tests/security/ChatReadOnlyTools.test.ts']],
  ['final-lint', ['bun','run','lint']],
  ['final-typecheck', ['bun','run','typecheck']],
] : [
  ['backend', ['bun','test','packages/server/tests/chat','packages/server/tests/academicYears','packages/server/tests/ownership','packages/server/tests/security/ChatDiagnostics.test.ts','packages/server/tests/security/ChatReadOnlyTools.test.ts']],
  ['lint', ['bun','run','lint']],
  ['typecheck', ['bun','run','typecheck']],
  ['boundaries', ['bun','run','test:boundaries']],
].filter(([name]) => (!process.argv.includes('--recheck') || name !== 'boundaries')
  && (!process.argv.includes('--boundaries') || name === 'boundaries'));
const results=await Promise.all(tasks.map(async([name,args])=>{
  const start=performance.now(), p=Bun.spawn(args,{stdout:'pipe',stderr:'pipe'});
  const [stdout,stderr,exitCode]=await Promise.all([new Response(p.stdout).text(),new Response(p.stderr).text(),p.exited]);
  await Bun.write('.cache/jev-final-'+name+'.log',stdout+'\n'+stderr);
  const result={name,command:args.join(' '),exitCode,elapsedMs:performance.now()-start,tests:(stderr+'\n'+stdout).match(/\d+ pass\n\s*\d+ fail/u)?.[0]};
  console.log(JSON.stringify(result));return result;
}));
await Bun.write(process.argv.includes('--final') ? '.cache/jev-final-final-checks.json' : process.argv.includes('--boundaries') ? '.cache/jev-final-boundary-checks.json' : process.argv.includes('--recheck') ? '.cache/jev-final-recheck.json' : '.cache/jev-final-checks.json',JSON.stringify(results,null,2));
if(results.some(r=>r.exitCode!==0))process.exit(1);
