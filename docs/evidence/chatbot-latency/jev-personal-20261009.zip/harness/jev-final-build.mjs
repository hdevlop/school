import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
const dist = '.next-jev-final-check', target = resolve('apps/dashboard', dist);
if (!target.startsWith(resolve('apps/dashboard') + '\\') || existsSync(target)) throw Error('Fresh owned build directory required');
const paths = ['apps/dashboard/next-env.d.ts', 'apps/dashboard/tsconfig.json'];
const before = new Map(paths.map(path => [path, readFileSync(path)]));
const start = performance.now();
let exitCode = 1;
try {
  const child = Bun.spawn(['bun', 'run', 'build'], { env: { ...process.env, NAJM_NEXT_DIST_DIR: dist }, stdout: 'pipe', stderr: 'pipe' });
  const [stdout, stderr, code] = await Promise.all([new Response(child.stdout).text(), new Response(child.stderr).text(), child.exited]);
  exitCode = code;
  writeFileSync('.cache/jev-final-build.log', stdout + stderr);
} finally {
  for (const path of paths) {
    const current = readFileSync(path, 'utf8');
    if (!current.includes(dist)) continue;
    const restored = current.replaceAll(dist, '.next');
    writeFileSync(path, restored === before.get(path).toString('utf8') ? before.get(path) : restored);
  }
}
const result = { cmd: ['bun', 'run', 'build'], exitCode, elapsedMs: performance.now() - start, dist,
  nextTypeReferencesRestored: !paths.some(path => readFileSync(path, 'utf8').includes(dist)),
  nextEnvExactRestoration: readFileSync(paths[0]).equals(before.get(paths[0])),
  tsconfigExactPreservation: readFileSync(paths[1]).equals(before.get(paths[1])) };
writeFileSync('.cache/jev-final-build.json', JSON.stringify(result, null, 2));
console.log(JSON.stringify(result));
process.exit(exitCode);
