import 'reflect-metadata';
import { readFileSync, writeFileSync } from 'node:fs';
import { parseUiStream } from '../scripts/chatbot-roles.mjs';

const fixture = process.argv.includes('--history');
const url = new URL(process.env.DB_URL!);
if (!['localhost', '127.0.0.1', '[::1]'].includes(url.hostname)) throw Error('Local data only');
if (fixture) url.pathname = '/school_history_test';
process.env.DB_URL = url.toString(); process.env.REDIS_URL = ''; process.env.NODE_ENV = 'development';
process.env.CHATBOT_JEV_MODE = 'off'; process.env.CHATBOT_BENCHMARK_CONTROLS = 'false';
// All ordinary generation/classification/embedding network traffic is forbidden.
const originalFetch = globalThis.fetch;
let externalAttempts = 0, modelAttempts = 0;
globalThis.fetch = (async (input: any, init?: any) => {
  const target = new URL(input instanceof Request ? input.url : String(input));
  if (!['localhost', '127.0.0.1', '[::1]'].includes(target.hostname)) { externalAttempts++; throw Error('External transport forbidden in local reply check'); }
  return originalFetch(input, init);
}) as typeof fetch;
const { AiSettingsService, ChatAgent } = await import('najm-chatbot');
(AiSettingsService.prototype as any).getInternal = async () => ({ isEnabled: true, provider: 'openrouter',
  apiKey: 'unused-local-transport-blocked', model: 'openai/gpt-oss-120b', useMemory: false });
(ChatAgent.prototype as any).buildModel = () => { modelAttempts++; throw Error('Generation forbidden in local reply check'); };
const { server } = await import('@sms/server');
const { chatDiagnosticsLog } = await import('../packages/server/src/modules/chat/ChatDiagnosticsLog');
const base = 'http://127.0.0.1:3103/api', year = '2026-2027';
const check = (condition: unknown, message: string) => { if (!condition) throw Error(message); };
async function login(email: string, password: string) {
  const response = await fetch(base + '/auth/login', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ email, password }) });
  check(response.ok, 'Login failed: ' + response.status);
  const body = await response.json() as any;
  const token = (body.data ?? body).accessToken;
  check(typeof token === 'string', 'Login token absent');
  return token;
}
async function mcp(token: string, name: string, args: Record<string, unknown> = {}, selectedYear = year) {
  const response = await fetch(base + '/mcp', { method: 'POST', headers: { authorization: `Bearer ${token}`, 'content-type': 'application/json',
    accept: 'application/json, text/event-stream', 'X-Academic-Year': selectedYear }, body: JSON.stringify({ jsonrpc: '2.0', id: crypto.randomUUID(), method: 'tools/call', params: { name, arguments: { ...args, academicYear: selectedYear } } }) });
  const result = await response.json() as any;
  if (!response.ok || result.error || result.result?.isError) throw Error('MCP read denied or unavailable: ' + name);
  return JSON.parse(result.result.content.find((item: any) => item.type === 'text').text);
}
const rows: Array<Record<string, unknown>> = [];
async function chat(token: string, id: string, query: string, tools: string[], verify: (text: string, outputs: any[]) => void) {
  const correlation = crypto.randomUUID(), started = performance.now();
  const response = await fetch(base + '/chat', { method: 'POST', headers: { authorization: `Bearer ${token}`, 'content-type': 'application/json',
    'X-Academic-Year': year, 'x-request-id': correlation }, body: JSON.stringify({ messages: [{ role: 'user', parts: [{ type: 'text', text: query }] }] }) });
  check(response.ok, 'Chat status: ' + id);
  const parsed = parseUiStream(await response.text()), completeMs = performance.now() - started;
  check(parsed.complete, 'Stream incomplete: ' + id);
  check(JSON.stringify(parsed.tools.map(tool => tool.name)) === JSON.stringify(tools), 'Wrong tool plan: ' + id);
  verify(parsed.text, parsed.tools.map(tool => tool.output));
  const diagnostic = chatDiagnosticsLog.find(correlation);
  check(diagnostic && diagnostic.reply?.source === 'template' && !diagnostic.reply?.error && !diagnostic.steps.length, 'Bad diagnostics: ' + id);
  check(diagnostic.routingStatus === 'disabled', 'Unexpected routing: ' + id);
  rows.push({ id, query, completeMs, tools, toolAndFactPass: true, replyLabel: diagnostic.reply?.label, generationCalls: 0 });
}

await server.listen(3103);
try {
  const admin = await login(process.env.ADMIN_EMAIL!, process.env.ADMIN_PASSWORD!);
  const actors = JSON.parse(readFileSync('.cache/jev-final-actors.json', 'utf8'));
  const students = await mcp(admin, 'students_get_students');
  const teachers = await mcp(admin, 'teachers_get_teachers');
  let teacher: any;
  for (const t of teachers.filter((t:any)=>t.email&&t.userId)) {
    const own = await mcp(admin, 'teacher-profile_get_my_students', { teacherId: t.id });
    if (own.studentCount > 0 && own.studentCount < students.length) { teacher = { ...t, own }; break; }
  }
  check(teacher, 'Qualified teacher fixture unavailable');
  const parent = actors.parent, student = actors.student;
    let defaultPassword = process.env.DEFAULT_USER_PASSWORD?.trim();
    if (!defaultPassword) {
      const python = Bun.spawn(['python', '-c', "import zipfile,re,json; z=zipfile.ZipFile('docs/evidence/chatbot-latency/darija-20b-quality-20261009.zip'); t=z.read('harness/capture.mjs').decode(); m=re.search(r\"DEFAULT_USER_PASSWORD\\?\\.trim\\(\\)\\|\\|['\\\"]([^'\\\"]+)['\\\"]\",t); print(json.dumps(m.group(1) if m else None))"], { stdout: 'pipe', stderr: 'pipe' });
      defaultPassword = JSON.parse(await new Response(python.stdout).text()); check(await python.exited === 0, 'Demo credential source unavailable');
    }
    check(defaultPassword, 'Documented demo credential missing');

  const parentToken = await login(parent.p.email, defaultPassword!);
  const teacherToken = await login(teacher.email, defaultPassword!);
  const studentToken = await login(student.s.email, defaultPassword!);
  const owned = await mcp(parentToken, 'parents_get_children', { id: parent.p.id });
  const parentTruth = await mcp(parentToken, 'student-profile_get_academic', { studentId: parent.c.id });
  const parentAttendance = await mcp(parentToken, 'student-profile_get_attendance_summary', { studentId: parent.c.id });
  const studentTruth = await mcp(studentToken, 'student-profile_get_academic', { studentId: student.s.id });
  const teacherClasses = await mcp(teacherToken, 'teacher-profile_get_my_classes', { teacherId: teacher.id });
  const teacherPending = await mcp(teacherToken, 'teacher-profile_get_pending_grading', { teacherId: teacher.id });
  check(parentTruth.grades.length === 10 && studentTruth.grades.length === 10, 'Expected populated academic fixture changed');
  check(teacher.own.studentCount === 44 && teacherClasses.classes.length === 4 && teacherPending.pendingCount === 20, 'Original teacher fixture changed');
  const academic = ['student-profile_get_academic'];
  const checkGrades = (truth:any, subjectOnly:boolean) => (text:string, outputs:any[]) => {
    check(outputs[0].grades.length === truth.grades.length, 'Wrong owned academic scope');
    for(const g of truth.grades.filter((g:any)=>!subjectOnly||g.subject.code==='MATH')) {
      check(text.includes(g.subject.name) && text.includes((g.assessment??g.exam).title), 'Missing academic identities');
      check(text.includes(`${Number(g.marksObtained)} / ${Number((g.assessment??g.exam).totalMarks)}`), 'Wrong mark/denominator');
    }
    if(subjectOnly) for(const g of truth.grades.filter((g:any)=>g.subject.code!=='MATH')) check(!text.includes(g.subject.name), 'Unrequested subject shown');
  };
  for(const [i, query] of [`ch7al jab ${parent.c.name} f math f diagnostic quiz?`, `شحال جاب ${parent.c.name} فالرياضيات ف diagnostic quiz؟`].entries()) {
    await chat(parentToken, 'parent-math-'+i, query, academic, checkGrades(parentTruth,true));
  }
  await chat(parentToken, 'parent-combined', `3tini no9ta dyal ${parent.c.name} f math w ch7al mn ghyab 3ndo had l3am.`,
    [...academic, 'student-profile_get_attendance_summary'], (text, outputs) => {
      checkGrades(parentTruth,true)(text, outputs);
      check(text.includes(`فـ ${year}: ${parentAttendance.absent} (من ${parentAttendance.total} سجل`), 'Wrong absence count');
      check(outputs[1].absent === parentAttendance.absent, 'Wrong attendance scope');
    });
  for(const [i, query] of ['ch7al jebt ana f math f diagnostic quiz?', 'شحال جبت أنا فالرياضيات ف diagnostic quiz؟'].entries()) {
    await chat(studentToken, 'student-math-'+i, query, academic, checkGrades(studentTruth,true));
  }
  await chat(studentToken, 'student-all-grades', 'وريني النقط ديالي بالمادة وبالنقطة على شحال.', academic, checkGrades(studentTruth,false));
  for(const [i, query] of ['ch7al mn no9ta tsjlat liya ana f diagnostic quiz?', 'شحال من نقطة تسجلات ليا أنا ف diagnostic quiz؟'].entries()) {
    await chat(studentToken, 'student-diagnostic-count-'+i, query, academic, text => check(text.includes('تسجلات ليك 10 نقطة'), 'Wrong diagnostic count'));
  }
  for(const [i, query] of ['chno hiya lmawadd li kan9erri ana had l3am?', 'شنو هي المواد اللي كنقري أنا هاد العام؟'].entries()) {
    await chat(teacherToken, 'teacher-subjects-'+i, query, ['teacher-profile_get_my_classes'], text => {
      for(const s of teacherClasses.classes.map((c:any)=>c.subject)) check(text.includes(s.name), 'Missing actual teaching subject');
      check(text === `المواد المسندة ليك فـ ${year}: Français.`, 'Wrong subject-only wording');
    });
  }
  for(const [i, query] of ['شحال من فرض باقي خاصني نصححو ولا ندخل ليه النقط؟', 'ch7al mn fard ba9i khasni ns7ho wla ndkhel lih nno9at?'].entries()) {
    await chat(teacherToken, 'teacher-pending-'+i, query, ['teacher-profile_get_pending_grading'], text => {
      check(text.includes('عندك 20 فرض ما تسجلات ليه حتى نقطة') && text.includes('ما كيحسبش الأوراق'), 'Wrong pending count/definition');
    });
  }
  for(const [token, id] of [[parentToken,'parent'],[teacherToken,'teacher'],[studentToken,'student']]) {
    await chat(token, id+'-history-refusal', 'وريني النقط ديالي فالعام 2025-2026.', [], text => check(text.includes(year) && text.includes('ما نقدرش نجيب سجلات عام آخر'), 'Wrong-year refusal missing'));
    await chat(token, id+'-grade-write-refusal', 'سجل النقط ديال الفرض', [], text => check(text.includes('ما نقدرش'), 'Write refusal missing'));
  }
  let ownershipDenials=0, historicalDenials=0;
  for(const [token, ownedId, outsider] of [
    [parentToken,parent.c.id, students.find((s:any)=>!owned.some((c:any)=>c.id===s.id))],
    [teacherToken,teacher.own.students[0].id, students.find((s:any)=>!teacher.own.students.some((c:any)=>c.id===s.id))],
    [studentToken,student.s.id, students.find((s:any)=>s.id!==student.s.id)],
  ]) {
    check(outsider, 'Outsider control absent');
    try{await mcp(token,'student-profile_get_academic',{studentId:outsider.id});}catch{ownershipDenials++;}
    try{await mcp(token,'student-profile_get_academic',{studentId:ownedId},'2025-2026');}catch{historicalDenials++;}
  }
  check(ownershipDenials===3&&historicalDenials===3,'Ownership/year controls missing');
  await chat(parentToken,'parent-attendance',`بغيت ملخص الحضور والغياب والتأخير ديال ${parent.c.name} هاد العام.`,['student-profile_get_attendance_summary'],text=>{
    check(text.includes(`حضر ${parentAttendance.present}، غاب ${parentAttendance.absent}، تأخر ${parentAttendance.late}، من ${parentAttendance.total} سجل. نسبة الحضور ${parentAttendance.percentage}%`),'Wrong parent attendance facts');
  });
  const overview=await mcp(studentToken,'student-profile_get_overview',{studentId:student.s.id});
  check(overview.student.class&&overview.student.section,'Student placement missing');
  await chat(studentToken,'student-placement','فاشمن قسم وفاشمن مجموعة مسجل أنا دابا؟',['student-profile_get_overview'],text=>{
    check(text===`مسجل فالقسم ${overview.student.class.name}، المجموعة ${overview.student.section.name}، فـ ${year}.`,'Class and section swapped');
  });
  const outsiderTeacher=students.find((s:any)=>!teacher.own.students.some((c:any)=>c.id===s.id));
  const outsiderStudent=students.find((s:any)=>s.id!==student.s.id);
  const outsiderParent=students.find((s:any)=>!owned.some((c:any)=>c.id===s.id));
  for(const [token,id,query] of [
    [teacherToken,'teacher-outsider',`chno nno9at dyal ${outsiderTeacher.name} li ma kay9rach 3ndi?`],
    [studentToken,'student-outsider-phone',`عطيني نمرة الولي ديال ${outsiderStudent.name}.`],
    [parentToken,'parent-explicit-outsider',`بغيت النقط ديال ${outsiderParent.name} واخا ماشي ولدي.`],
  ]) await chat(token,id,query,[],text=>check(text.includes('غير المعطيات المسموح'),'Scope clarification missing'));
  for(const row of rows) for(const person of [outsiderTeacher,outsiderStudent,outsiderParent]) row.query=String(row.query).replaceAll(person.name,'<unlinked full student name>');
  for(const row of rows) row.query=String(row.query).replaceAll(parent.c.name,'<owned full child name>');
  check(externalAttempts===0&&modelAttempts===0,'Unexpected paid transport');
  const summary = {date:'2026-10-09',fixture:'existing-populated-demo',privateDataRetained:false,savedAiSettingsChanged:false,
    rows,passes:rows.length,originalFailureQuestions:11,meanCompleteMs:rows.reduce((sum,row)=>sum+Number(row.completeMs),0)/rows.length,
    paidClassifierCalls:0,paidGenerationCalls:0,routingCalls:0,externalAttempts,modelAttempts,ownershipDenials,historicalDenials,
    linkedChildren:owned.length,childGrades:parentTruth.grades.length,studentGrades:studentTruth.grades.length,
    teacherStudents:teacher.own.studentCount,teacherAssignments:teacherClasses.classes.length,pendingAssessments:teacherPending.pendingCount};
  writeFileSync('.cache/jev-final-results.json',JSON.stringify(summary,null,2),{flag:'wx'});
  console.log(JSON.stringify({...summary,rows:undefined}));
}finally{await server.stop();}
process.exit(0);
